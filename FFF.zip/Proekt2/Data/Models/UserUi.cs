﻿using System;
using System.Collections.Generic;

namespace Proekt2.Models
{
    public partial class UserUi
    {
        public int Id { get; set; }
        public int id_user { get; set; }
        public string Ui1 { get; set; }
        public string Ui2 { get; set; }
    }
}
