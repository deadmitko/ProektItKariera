﻿
using Proekt2.Data.Models;
using Proekt2.Display;
using System;
using System.IO;
using System.Windows;
using System.Security.Permissions;
using System.Drawing;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Security;
using View = Proekt2.Display.View;
using System.Diagnostics;
using System.Threading;

namespace Proekt2
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            //Process.Start(@"D:\ark\fizika\Proekt3\Proekt2\bin\Debug\netcoreapp3.0\Proekt2.Exe");
            View test = new View();
            while(true) test.Menu();
            


        }
    }
}
