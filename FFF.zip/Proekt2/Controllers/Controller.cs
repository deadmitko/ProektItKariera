﻿using Proekt2.Data.Models;
using Proekt2.Data;
using System;
using System.Collections.Generic;
using System.Text;
using Proekt2.Models;
using System.IO;
using System.Linq;

namespace Proekt2.Controllers
{
    public class Controller
    {
        public proektContext db;
        public Users test;
        public UserUi inter;
        public Controller()
        {   
            db = new proektContext();
            test = new Users();
            inter = new UserUi();
            
           
        }
        public void register(string username,string password,string first,string last,string email)
        {
           
            test.Username = username;
            test.Password = password;
            test.First = first;
            test.Last = last;
            test.Email = email;
            db.Users.Add(test);
            db.SaveChanges();
            inter.id_user = test.Id;
            db.UserUi.Add(inter);
           db.SaveChanges();
            DirectoryInfo di = Directory.CreateDirectory(@"C:\\server\\"+test.Username);



        }
        public string login(string username,string password)
        {

            var user = db.Users.Where(x => x.Username == username && x.Password == password).FirstOrDefault();
            if (user != null)
                {
                    test.Id = user.Id;
                    test.Username = user.Username;
                    test.Password = user.Password;
                    test.First = user.First;
                    test.Last = user.Last;
                    test.Email = user.Email;
               // Console.WriteLine("uspeheshen");
                //Console.WriteLine("control " +test.Id);
                
                    return "Login uspeshen";
                   
                
                }
                else
                {
                
                    return "Login neuspeshen";
                
                }
                
            
            

        }
        
        public void ChangePass(string old,string nova)
        {
            var user = db.Users.SingleOrDefault(x => x.Id == test.Id);
            if (test.Password == old)
            {
                test.Password = nova;
                user.Password = nova;
                db.SaveChanges();
            }
        }
        public void ChangeMail(string password,string novemail)
        {
            var user = db.Users.SingleOrDefault(x => x.Id == test.Id);
            if (test.Password == password)
            {
                test.Email = novemail;
                user.Email = novemail;
                db.SaveChanges();
            }
        }
        public  void u1(int chislo)
        {

            var interfa= db.UserUi.SingleOrDefault(x => x.id_user == test.Id);
            switch (chislo)
            {
                case 0:
                    Console.Clear();
                   
                    break;
                case 1:
                    interfa.Ui1 = "black";
                    
                    Console.BackgroundColor = ConsoleColor.Black;

                    break;
                case 2:
                    interfa.Ui1 = "blue";
                    
                    Console.BackgroundColor = ConsoleColor.Blue;
                    break;
                case 3:
                    interfa.Ui1 = "cyan";
                    
                    Console.BackgroundColor = ConsoleColor.Cyan;
                    break;
                case 4:
                    interfa.Ui1 = "darkblue";
                    
                    Console.BackgroundColor = ConsoleColor.DarkBlue;
                    break;
                case 5:
                    interfa.Ui1 = "darkgreen";
                    
                    Console.BackgroundColor = ConsoleColor.DarkGreen;
                    break;
                case 6:
                    interfa.Ui1 = "darkmagenta";
                    
                    Console.BackgroundColor = ConsoleColor.DarkMagenta;
                    break;
                case 7:
                    interfa.Ui1 = "darkred";
                    
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    break;
                case 8:
                    interfa.Ui1 = "darkyellow";
                    
                    Console.BackgroundColor = ConsoleColor.DarkYellow;
                    break;
                case 9:
                    interfa.Ui1 = "gray";
                    
                    Console.BackgroundColor = ConsoleColor.Gray;
                    break;
                case 10:
                    interfa.Ui1 = "green";
                    
                    Console.BackgroundColor = ConsoleColor.Green;
                    break;
                case 11:
                    interfa.Ui1 = "magenta";
                    
                    Console.BackgroundColor = ConsoleColor.Magenta;
                    break;
                case 12:
                    interfa.Ui1 = "red";
                    
                    Console.BackgroundColor = ConsoleColor.Red;
                    break;
                case 13:
                    interfa.Ui1 = "white";
                    
                    Console.BackgroundColor = ConsoleColor.White;
                    break;
                case 14:
                    interfa.Ui1 = "yellow";
                    
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    break;
                case 15:
                    interfa.Ui1 = "darkgray";
                    
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    break;
            }
            db.SaveChanges();
        }
        public  void u2(int chislo)
        {

            var interfa = db.UserUi.SingleOrDefault(x => x.id_user == test.Id);
            switch (chislo)
            {
                case 0:
                    Console.Clear();
                   
                    break;
                case 1:
                    interfa.Ui2= "black";
                    
                    Console.ForegroundColor = ConsoleColor.Black;
                    break;
                case 2:
                    interfa.Ui2 = "blue";
                    
                    Console.ForegroundColor = ConsoleColor.Blue;
                    break;
                case 3:
                    interfa.Ui2 = "cyan";
                    
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    break;
                case 4:
                    interfa.Ui2 = "darkblue";
                    
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                    break;
                case 5:
                    interfa.Ui2 = "darkgreen";
                    
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    break;
                case 6:
                    interfa.Ui2 = "darkmagenta";
                    
                    Console.ForegroundColor = ConsoleColor.DarkMagenta;
                    break;
                case 7:
                    interfa.Ui2 = "darkred";
                   
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    break;
                case 8:
                    interfa.Ui2 = "darkyellow";
                    
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    break;
                case 9:
                    interfa.Ui2 = "gray";
                    
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                case 10:
                    interfa.Ui2 = "green";
                    
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case 11:
                    interfa.Ui2 = "magenta";
                    
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    break;
                case 12:
                    interfa.Ui2 = "red";
                    
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                case 13:
                    interfa.Ui2 = "white";
                     
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case 14:
                    interfa.Ui2 = "yellow";
                     
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    break;
                case 15:
                    interfa.Ui2 = "darkgray";
                     
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    break;
            }
            db.SaveChanges();
        }
        public string check_u1()
        {
            var interfa = db.UserUi.SingleOrDefault(x => x.id_user == test.Id);
            return interfa.Ui1; 
        }
        public string check_u2()
        {
            var interfa = db.UserUi.SingleOrDefault(x => x.id_user == test.Id);
            return interfa.Ui2; 
        }
        public void uploader(string path)
        {
            Files fail = new Files();
            var ime = Path.GetFileName(path);
            var put = Path.GetFullPath(path);
            var extension = Path.GetExtension(path);
           var size = new FileInfo(path).Length;
            fail.Name = ime;
                fail.Ext = extension;
                fail.File = @"C:\server\" + test.Username + @"\" + fail.Name;
                fail.Size = size.ToString();
                fail.IdUser = test.Id;
                
                db.Files.Add(fail);
                db.SaveChanges();

            File.Copy(put, @"C:\server\" + test.Username + @"\" + fail.Name);
           
        }
        public List<Files> showallfiles()
        {
            List<Files> spisuk = new List<Files>();
            foreach (var fail in db.Files)
            {
                if (fail.IdUser == test.Id) { spisuk.Add(fail); }
            }
            return spisuk;


        }
        public Files info(int id)
        {
            Files failat = new Files();
            foreach (var fail in db.Files)
            {
                if(fail.Id == id && fail.IdUser == test.Id) { failat = fail; }
            }
            return failat;
        }
        public Files downloader(int id)
        {
            Files failat = new Files();
            foreach (var fail in db.Files)
            {
                if(fail.Id == id && fail.IdUser == test.Id) { failat = fail; }
            }
            return failat;

        }
        public void download(Files fail,string output)
        {

            File.Copy(@"C:\server\" + test.Username + @"\" + fail.Name,output+fail.Name);
        }
        public void remover(int id)
        {
            var test2 = db.Files.Where(x => x.Id == id && x.IdUser == test.Id).SingleOrDefault();
            File.Delete(@"C:\server\" + test.Username + @"\" + test2.Name);
            db.Files.Remove(test2);
            db.SaveChanges();




        }
        public void renamer(int id)
        {
            string novoime = Console.ReadLine();
            var test2 = db.Files.Where(x => x.Id == id && x.IdUser == test.Id).SingleOrDefault();
            File.Move(@"C:\server\" + test.Username + @"\" + test2.Name, @"C:\server\" + test.Username + @"\" + novoime + "" + test2.Ext);
            test2.File=@"C:\server\" + test.Username + @"\" + novoime+""+test2.Ext;
            test2.Name = novoime+""+test2.Ext;
            db.SaveChanges();




        }

    }
}
