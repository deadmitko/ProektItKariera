﻿using Proekt2.Data.Models;
using Proekt2.Display;
using System;
using System.IO;

namespace Proekt2
{
    class Program
    {
        static void Main(string[] args)
        {
            View test = new View();
            
                test.Menu();
            
        }
    }
}
