﻿using ConsoleApp28.Controllers;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp28.Display
{
    public class View
    {
        private Controller control;
        public View()
        {
            control = new Controller();
        }
        public void register()
        {

            Console.WriteLine("Register");
            Console.Write("Username:");
            var username = Console.ReadLine();
            Console.Write("Password:");
            var password = Console.ReadLine();
            control.register(username, password);
        }
        public void login()
        {
            Console.WriteLine("Login");
            Console.Write("Username:");
            var username = Console.ReadLine();
            Console.Write("Password:");
            var password = Console.ReadLine();
            control.login(username, password);
        }
        public void Menu()
        {
            Console.Title = "AtaDim";
            if (control.user.Id == 0)
            {
                Console.WriteLine("1.Register");
                Console.WriteLine("2.Login");
                switch (int.Parse(Console.ReadLine()))
                {
                    case 2:
                        while (control.user.Id == 0)
                        {
                            Console.Clear();
                            login();
                            Console.WriteLine(control.user.Id);
                            Console.ReadLine();
                        }
                        break;
                    case 1:
                        while (control.user.Id == 0)
                        {
                            register();
                            Console.Clear();
                        }
                        break;
                }
            }
            else
            {
                






            }
        }
    }
}