﻿using ConsoleApp28.Display;
using System;

namespace ConsoleApp28
{
    class Program
    {
        static void Main(string[] args)
        {
            View test = new View();
            while (true) test.Menu();
        }
    }
}
