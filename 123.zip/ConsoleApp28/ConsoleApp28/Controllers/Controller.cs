﻿using ConsoleApp28.Data.Models;
using ConsoleApp28.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp28.Controllers
{

    public class Controller
    {
        private proektContext db;
        public Users user;
        public Controller()
        {
            db = new proektContext();
            user = new Users();
        }
        public void register(string username, string password)
        {

            user.Username = username;
            user.Password = password;

            db.Users.Add(user);
            db.SaveChanges();

        }
        public string login(string username, string password)
        {
            var user = db.Users.Where(x => x.Username == username && x.Password == password).FirstOrDefault();
            if (user != null)
            {
                this.user.Id = user.Id;
                user.Username = user.Username;
                user.Password = user.Password;
                return "Login uspeshen";
            }
            else
            {
                return "Login neuspeshen";
            }
        }
    
        public void ChangePass(string old, string nova)
        {
            var user = db.Users.SingleOrDefault(x => x.Id == this.user.Id);
            if (user.Password == old)
            {
                user.Password = nova;
                
                db.SaveChanges();
            }
        }
        public List<Receipts> Getall()
        {
            List<Receipts> test = new List<Receipts>();
           
            
                foreach (var item in db.Receipts)
                {
                    test.Add(item);
                }                        
            return test;
        }
        public List<Favourites> GetFavourites()
        {
            List<Favourites> test = new List<Favourites>();
            foreach (var item in db.Favourites)
            {
                test.Add(item);
            }
            return test;
        }       
    }
}
