﻿using System;
using System.Collections.Generic;

namespace ConsoleApp28.Models
{
    public partial class Users
    {
        public Users()
        {
            Favourites = new HashSet<Favourites>();
        }

        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        

        public virtual ICollection<Favourites> Favourites { get; set; }
    }
}
